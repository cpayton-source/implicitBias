//
//  ViewController.swift
//  ImplicitBias_TeamSeven
//
//  Created by Cam Payton on 4/5/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


//
//  Question.swift
//  TeamSeven
//
//  Created by Cam Payton on 4/30/23.
//

import Foundation
struct Question {
    var text: String
    var type: ResponseType
    var answers: [Answer]
}
enum ResponseType {
    case single
}
struct Answer {
    var text: String
    var type: BiasOrNot
}
enum BiasOrNot: Character {
    case Age = "😡",
         Gender = "👨‍👩‍👦‍👦",
         Race = "🤯",
         Sex = "🤥"
    var definition: String {
            switch self {
            case .Age:
                return "You have an Age Bias. Please study the age bias tab."
            case .Gender:
                return "You have a Gender Bias. Please study the gender tab."
            case .Race:
                return "You have a Race Bias. Please study the race tab."
            case .Sex:
                return "You have a Sexuality Bias. Please study the sex tab."
            }
        }
}

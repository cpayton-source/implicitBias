//
//  ViewController.swift
//  TeamSeven
//
//  Created by Cam Payton on 4/29/23.
//

import UIKit

class IntroductionViewController: UIViewController {
    @IBOutlet var usernameText: UITextField!
    
    @IBOutlet var passwordText: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let users : [String: String] = ["Isata" : "Sankoh",
                                        "Justin": "Griffin",
                                        "Cameron": "Payton"]
        var cnt = 0
        for (username, password) in users{
            if usernameText.text == username && passwordText.text == password{
                segue.destination.navigationItem.title = usernameText.text
                cnt = 1
            }
        }
        if cnt != 1 {
            segue.destination.navigationItem.title = "Unknown"
        }
        
    }
    @IBAction func unwindToQuizIntroduction(segue:
    UIStoryboardSegue) {
    }

}


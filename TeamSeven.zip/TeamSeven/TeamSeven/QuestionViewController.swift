//
//  QuestionViewController.swift
//  TeamSeven
//
//  Created by Cam Payton on 4/30/23.
//

import UIKit

class QuestionViewController: UIViewController {

    @IBOutlet var singleStackView: UIStackView!

    @IBOutlet var singleButton1: UIButton!
    
    @IBOutlet var singleButton2: UIButton!
    
    @IBOutlet var singleButton3: UIButton!
    
    @IBOutlet var singleButton4: UIButton!

    @IBOutlet var questionLabel: UILabel!
    

    @IBOutlet var questionProgressView: UIProgressView!
    var questions: [Question] = [
      Question(
        text: "What is the first thing you notice when looking at someone?",
        type: .single,
        answers: [
          Answer(text: "Age", type: .Age),
          Answer(text: "Gender", type: .Gender),
          Answer(text: "Race", type: .Race),
          Answer(text: "Sexuality", type: .Sex)
        ]
      ),
      Question(
        text: "Old man for physical labor?",
        type: .single,
        answers: [
          Answer(text: "No, they are too weak.", type: .Age),
          Answer(text: "I wish I had a woman doing this", type: .Gender),
          Answer(text: "What is their racial background?", type: .Race),
          Answer(text: "Who have they dated?", type: .Sex)
        ]
      ),
      Question(
        text: "Person walks by you.",
        type: .single,
        answers: [
          Answer(text: "They are too old to be wearing that", type: .Age),
          Answer(text: "That would look nicer on a man", type: .Gender),
          Answer(text: "Those kind of people may be dangerous", type: .Race),
          Answer(text: "I hope they aren't into me", type: .Sex)
        ]
      ),
      Question(
        text: "Couple walks by.",
        type: .single,
        answers: [
          Answer(text: "They are too old to be so lovey dovey.", type: .Age),
          Answer(text: "The man should be in charge!", type: .Gender),
          Answer(text: "I hate seeing those races together", type: .Race),
          Answer(text: "I can't look at same sex couples.", type: .Sex)
        ]
      ),
      Question(
        text: "Choose what you think",
        type: .single,
        answers: [
          Answer(text: "Old people are so wrinkly", type: .Age),
          Answer(text: "I can't trust a woman for this", type: .Gender),
          Answer(text: "Certain races are evil", type: .Race),
          Answer(text: "I don't like certain sexualities", type: .Sex)
        ]
      ),
      Question(
        text: "Choose what you think",
        type: .single,
        answers: [
          Answer(text: "I won't hire past a certain age.", type: .Age),
          Answer(text: "I won't hire a certain gender", type: .Gender),
          Answer(text: "I won't hire a certain race", type: .Race),
          Answer(text: "I won't hire a gay man", type: .Sex)
        ]
      ),
      Question(
        text: "Choose what you think",
        type: .single,
        answers: [
          Answer(text: "Can these old people walk faster.", type: .Age),
          Answer(text: "This gender is the problem", type: .Gender),
          Answer(text: "This race is so funny to me", type: .Race),
          Answer(text: "These two should not be holding hands", type: .Sex)
        ]
      ),
      Question(
        text: "Choose what you think",
        type: .single,
        answers: [
          Answer(text: "If you are too young you cannot be taken serious", type: .Age),
          Answer(text: "A certain gender gets on my nerves", type: .Gender),
          Answer(text: "I don't like this race at all", type: .Race),
          Answer(text: "Keep that same sex stuff away from me", type: .Sex)
        ]
      ),
      Question(
        text: "Choose what you think",
        type: .single,
        answers: [
          Answer(text: "Old people are weird to me.", type: .Age),
          Answer(text: "Couldn't agree more", type: .Gender),
          Answer(text: "I don't like certain races", type: .Race),
          Answer(text: "Not if he is gay.", type: .Sex)
        ]
      ),
      Question(
        text: "Would you stand up for a lady if she was old.",
        type: .single,
        answers: [
          Answer(text: "Of course not!", type: .Age),
          Answer(text: "Women need a man's help!", type: .Gender),
          Answer(text: "What's her race?", type: .Race),
          Answer(text: "Depends on what her dating history is like", type: .Sex)
        ]
      ),
    ]
    var questionIndex = 0
    var answersChosen: [Answer] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
        // Do any additional setup after loading the view.
    }
    func nextQuestion() {
        questionIndex += 1
        if questionIndex < questions.count {
            updateUI()
        } else {
            performSegue(withIdentifier: "Results", sender: nil)
        }
    }
    
    @IBAction func singleAnswerButtonPressed(_ sender: UIButton) {
        let currentAnswers = questions[questionIndex].answers
            switch sender {
            case singleButton1:
                answersChosen.append(currentAnswers[0])
            case singleButton2:
                answersChosen.append(currentAnswers[1])
            case singleButton3:
                answersChosen.append(currentAnswers[2])
            case singleButton4:
                answersChosen.append(currentAnswers[3])
            default:
                break
            }
            nextQuestion()
    }
    
    
    @IBSegueAction func showResults(_ coder: NSCoder) -> ResultsViewController? {
        return ResultsViewController(coder: coder, responses: answersChosen)
    }
    
    
    
    
    
    
    func updateUI(){

        let currentQuestion = questions[questionIndex]
        let currentAnswers = currentQuestion.answers
        let totalProgress = Float(questionIndex) / Float(questions.count)

        navigationItem.title = "Question #\(questionIndex + 1)"
        questionLabel.text = currentQuestion.text
        questionProgressView.setProgress(totalProgress, animated:true)
        if questionIndex <= 9 {
            updateSingleStack(using: currentAnswers)
        }
    }
    func updateSingleStack(using answers: [Answer]) {
        singleButton1.setTitle(answers[0].text, for: .normal)
        singleButton2.setTitle(answers[1].text, for: .normal)
        singleButton3.setTitle(answers[2].text, for: .normal)
        singleButton4.setTitle(answers[3].text, for: .normal)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
